﻿using UnityEngine;

public class RocketFly : MonoBehaviour {

    public static float rocketspeed = 1f * 5;
    private GameObject point;
    private float angle;
    // Use this for initialization
    void Start() {
        point = GameObject.FindGameObjectWithTag("Point");
        angle = Mathf.Atan(point.transform.position.y / point.transform.position.x) * 180 / Mathf.PI;
        if (point.transform.position.x < 0) angle += 180;
        PlaneFly.rocketfly = true;
    }

    // Update is called once per frame
    void Update() {
        if (transform.position.x < -3.5f || transform.position.x > 3.5f || transform.position.y < -5.5f || transform.position.y > 5.5f)
        {
            Destroy(gameObject);
        }
        if (point != null)
        {
            angle = Mathf.Atan((point.transform.position.y - transform.position.y) / (point.transform.position.x - transform.position.x)) * 180 / Mathf.PI;
            if (point.transform.position.x < transform.position.x) angle += 180;
        }
        float vx = rocketspeed * Mathf.Cos(angle * Mathf.PI / 180f);
        float vy = rocketspeed * Mathf.Sin(angle * Mathf.PI / 180f);
        float x = vx * Time.deltaTime;
        float y = vy * Time.deltaTime;
        transform.position += new Vector3(x, y);
        transform.rotation = Quaternion.Euler(0, 0, angle);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Plane")
        {
            GameObject plane = GameObject.FindGameObjectWithTag("Plane");
            GameObject[] points = GameObject.FindGameObjectsWithTag("Point");
            foreach (GameObject i in points)
            {
                Destroy(i);
            }
            Destroy(plane);
            Destroy(gameObject);
        }
    }
}
