﻿using UnityEngine;

public class Start : MonoBehaviour {

    public GameObject rocket;

    void OnMouseDown()
    {
        GameObject point = GameObject.FindGameObjectWithTag("Point");
        GameObject rocket1 = GameObject.FindGameObjectWithTag("Rocket");
        if (!PlaneFly.rocketfly) Destroy(rocket1);
        if (point != null && !PlaneFly.rocketfly)
        {
            float angle = Mathf.Atan(point.transform.position.y / point.transform.position.x) * 180 / Mathf.PI;
            if (point.transform.position.x < 0) angle += 180;
            Instantiate(rocket, new Vector2(0, 0), Quaternion.Euler(0, 0, angle));
        }
    }
}
