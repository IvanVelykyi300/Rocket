﻿using UnityEngine;

public class PlaneCreate : MonoBehaviour
{
    public GameObject plane;
    // Use this for initialization
    void Start()
    {
        CreatePlane();
    }
    
    public void CreatePlane()
    {
        float x = 0, y = 0, angle = 0;
        float i = Random.Range(0f, 4f);
        if (i < 1)
        {
            x = -3.5f;
            y = Random.Range(-5.5f, 5.5f);
            angle = Random.Range(210f, 330f);
        }
        else
        {
            if (i < 2)
            {
                x = Random.Range(-3.5f, 3.5f);
                y = 5.5f;
                angle = Random.Range(120f, 240f);
            }
            else
            {
                if (i < 3)
                {
                    x = 3.5f;
                    y = Random.Range(-5.5f, 5.5f);
                    angle = Random.Range(30f, 150f);
                }
                else
                {
                    x = Random.Range(-3.5f, 3.5f);
                    y = -5.5f;
                    angle = Random.Range(-60f, 60f);
                }
            }
        }
        Instantiate(plane, new Vector2(x, y), Quaternion.Euler(0, 0, angle));
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.FindGameObjectsWithTag("Plane").GetLength(0) == 0) CreatePlane();
    }
}
