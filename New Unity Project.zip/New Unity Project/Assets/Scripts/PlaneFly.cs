﻿using UnityEngine;

public class PlaneFly : MonoBehaviour {

    private float speed;
    private float rocketspeed = RocketFly.rocketspeed;
    public GameObject point;
    private GameObject thispoint;
    public static bool rocketfly = false;
    public float phi = 0;
    void Start () {
        speed = Random.Range(0.2f, 0.4f) * 5;
        thispoint = Instantiate(point, new Vector2(transform.position.x, transform.position.y), Quaternion.identity);
        rocketfly = false;
        float traectory = Random.Range(0f, 3f);
        if(traectory > 1)
        {
            float rad = Random.Range(5f, 10f);
            phi = (speed * Time.deltaTime) / rad;
            if (traectory > 2) phi *= -1;
        }
    }
	
	// Update is called once per frame
	void Update () {
        if(transform.position.x < -3.5f || transform.position.x > 3.5f || transform.position.y < -5.5f || transform.position.y > 5.5f)
        {
            Destroy(gameObject);
            Destroy(thispoint);
        }
        float angle = transform.eulerAngles.z;
        float vx = 0, vy = 0, x = 0, y = 0;
        vx = -speed * Mathf.Sin((angle * Mathf.PI / 180f) + phi);
        vy = speed * Mathf.Cos((angle * Mathf.PI / 180f) + phi);
        x = vx * Time.deltaTime;
        y = vy * Time.deltaTime;
        angle += phi * 180f / Mathf.PI;
        transform.rotation = Quaternion.Euler(0, 0, angle);
        transform.position += new Vector3(x, y);
        float xr = 0, yr = 0;
        GameObject rocket = GameObject.FindGameObjectWithTag("Rocket");
        if (rocketfly && rocket != null)
        {
            xr = rocket.transform.position.x;
            yr = rocket.transform.position.y;
        }
        x = transform.position.x;
        y = transform.position.y;
        float div = (y - yr) / (x - xr);
        float a = vy - div * vx;
        float aa = div * div + 1;
        float D = 4 * div * div * a * a - 4 * aa * (a * a - rocketspeed * rocketspeed);
        float vx1 = (-2 * div * a + Mathf.Sqrt(D)) / (2 * aa);
        float vx2 = (-2 * div * a - Mathf.Sqrt(D)) / (2 * aa);
        float vxr = 0;
        if (Mathf.Sign(x - xr) == Mathf.Sign(vx1 - vx)) vxr = vx1;
        else vxr = vx2;
        float xl = (x * vxr - xr * vx) / (vxr - vx);
        float yl = Mathf.Tan((angle - 270) * Mathf.PI / 180f) * (xl - x) + y;
        thispoint.transform.position = new Vector3(xl, yl);
    }
}
